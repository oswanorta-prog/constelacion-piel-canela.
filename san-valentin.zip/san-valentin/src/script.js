const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");
const poemSection = document.getElementById("poemSection");
const poemText = document.getElementById("poemText");
const sectionTitle = document.getElementById("sectionTitle");
const nextBtn = document.getElementById("nextBtn");
const decorations = document.getElementById("decorations");

let yesScale = 1;
let noScale = 1;

noBtn.addEventListener("mouseenter", () => {
  const x = Math.random() * 200 - 100;
  const y = Math.random() * 100 - 50;
  noScale -= 0.1;
  yesScale += 0.15;

  noBtn.style.transform = `translate(${x}px, ${y}px) scale(${noScale})`;
  yesBtn.style.transform = `scale(${yesScale})`;

  if (noScale <= 0.3) {
    noBtn.style.display = "none";
  }
});

yesBtn.addEventListener("click", () => {
  document.querySelector(".buttons").style.display = "none";
  poemSection.classList.remove("hidden");
  startPoem();
});

const sections = [
  {
    title: "🌌✨ I. La Física de tu Presencia ✨🌌",
    deco: "✨🌌💫",
    text: `No eres solo materia, mi negra, eres la curvatura
donde el espacio-tiempo se rinde y se detiene.
Si Einstein predijo que la luz se dobla ante el vacío,
mi luz se dobla ante el abismo de tus ojos azabache,
esos donde el universo colapsa y vuelve a nacer.
Tus besos no son azar, son entropía inversa:
en medio del caos del mundo, tu boca me ordena los átomos.`
  },
  {
    title: "📚💭 II. La Filosofía del Encuentro 💭📚",
    deco: "📚✨💖",
    text: `Decía Platón que buscamos la mitad de nuestra esencia,
pero al verte, entiendo que la unidad es un concepto pobre.
Eres el imperativo categórico de Kant:
mi única ley moral es amarte sin condiciones.
Y como Sartre, me sé condenado a mi libertad,
pero elijo libremente el exilio entre tus brazos,
porque fuera de tu cuerpo, el mundo es puro no-ser.`
  },
  {
    title: "✍️🌙 III. El Eco de los Maestros 🌙✍️",
    deco: "🌙✨📖",
    text: `Si Benedetti te viera, diría que tu mirada es una comarca.
Neruda escribiría que tienes el color del trigo doble.
Safo sentiría el pulso romperse ante tu cuello,
y Rumi juraría que tu risa es el sonido
de Dios regresando a casa tras un largo silencio.`
  },
  {
    title: "💌✨ IV. La Petición del Poeta ✨💌",
    deco: "💖✨🌹",
    text: `No busco un regalo efímero,
busco un pacto con tu belleza.
Quiero pedirte que seas mi musa,
mi centro y mi norte,
y que este febrero me permitas
adorar la constelación que llevas por piel.`
  },
  {
    title: "🌈🐸 V. El Reino de la Nostalgia 🐸🌈",
    deco: "🌈🐸⭐💖",
    text: `Eres la aventura que ningún mapa contiene,
la dulzura de Tutti Frutti,
el abrazo que brilla como un Osito Cariñosito.
A tu lado soy todo lo que Barbie prometía,
y si este fuera un pantano nocturno,
te cantaría como Ray a su estrella,
porque tú eres mi Evangeline eterna.`
  }
];

let current = 0;

function typeText(text, i = 0) {
  if (i < text.length) {
    poemText.innerHTML += text[i] === "\n" ? "<br>" : text[i];
    setTimeout(() => typeText(text, i + 1), 35);
  } else {
    nextBtn.classList.remove("hidden");
  }
}

function startPoem() {
  loadSection();
}

function loadSection() {
  poemText.innerHTML = "";
  nextBtn.classList.add("hidden");

  const section = sections[current];
  sectionTitle.textContent = section.title;
  decorations.textContent = section.deco;

  setTimeout(() => typeText(section.text), 400);
}

nextBtn.addEventListener("click", () => {
  current++;
  if (current < sections.length) {
    loadSection();
} else {
  sectionTitle.textContent = "💫💖 Fin, ¿aceptas mi constelación? 💖💫";
  decorations.textContent = "🌌✨⭐🐸💞";
  poemText.innerHTML = `
  No hay más versos que escribir,
  porque todos terminan en ti.<br><br>
  ¿Aceptas ser el centro de este universo
  que desde hoy solo sabe orbitar tu nombre? 💖
  `;
  nextBtn.style.display = "none";
}
});
